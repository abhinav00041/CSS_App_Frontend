import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stackholders',
  templateUrl: './stackholders.component.html',
  styleUrls: ['./stackholders.component.css']
})
export class StackholdersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
