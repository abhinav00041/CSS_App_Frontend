import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Rating } from "./rating.model";

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http: HttpClient) {}
  myData: Rating;
  isLoggedIn: boolean = false;

  public getJSON(): Observable<any> {
    return this.http.get<Rating[]>("./assets/mockData.json");
  }

  setSelectedData(data: Rating) {
    this.myData = data;
  }

  getSelectedData() {
    return this.myData;
  }
  isUserLoggedIn() {
    return this.isLoggedIn;
  }
}
